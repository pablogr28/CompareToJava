package main.java.model.figura;

public class CreadorFiguras {
	
}
