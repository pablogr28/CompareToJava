
/*Desarrolla una clase Triángulo con un array como atributo donde se almacena la
longitud de cada uno de sus tres lados. Si no se facilita ningún valor durante su
construcción o alguno de ellos es incorrecto, se tomará el triángulo isósceles de lado
1 por defecto.
Crea un getter/setter asociado a cada uno de los lados y al igual que con la clase
anterior, dos métodos públicos calcularArea y calcularPerimetro.
Incluye tres métodos que nos indiquen si el triángulo que se ha construido es
isósceles, equilatero, escaleno.package main.java.model;*/

package main.java.model.figura;

public class Triangulo extends Figura implements Comparable<Triangulo> {
    private double lado1;
    private double lado2;
    private double lado3;
    
    public Triangulo() {
        this.lado1 = 1;
        this.lado2 = 1;
        this.lado3 = 1;
    }
    
    public Triangulo(double lado1, double lado2, double lado3) {
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }
    
    // Métodos getter y setter existentes...
    
    public String tipoTriangulo() {
        if (lado1 == lado2 && lado1 == lado3) {
            return "Equilatero";
        } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
            return "Isósceles";
        } else {
            return "Escaleno";
        }
    }
    
    public double calcularArea() {
        double semiperimetro = (lado1 + lado2 + lado3) / 2;
        return Math.sqrt(semiperimetro * (semiperimetro - lado1) * (semiperimetro - lado2) * (semiperimetro - lado3));
    }
    
    public double calcularPerimetro() {
        return lado1 + lado2 + lado3;
    }
    
    @Override
    public void mostrarInformacion() {
        System.out.println("Este es un triángulo " + tipoTriangulo() + " con lados " + lado1 + ", " + lado2 + " y " + lado3);
    }
    
    @Override
    public int compareTo(Triangulo otroTriangulo) {
        if (otroTriangulo == null) {
            return 1; 
        }
        double areaActual = this.calcularArea();
        double areaOtro = otroTriangulo.calcularArea();
        return Double.compare(areaActual, areaOtro);
    }
    
    
}


