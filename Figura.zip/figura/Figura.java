/*Piensa en una clase que pueda ser padre de las dos anteriores, ¿cómo la llamarías
y de qué constructores, atributos y comportamiento le dotarías? Dibuja un diagrama
uml con esta relación.*/

package main.java.model.figura;

public class Figura {
    private String color;
    private String nombre;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void mostrarInformacion() {
        System.out.println("Esta es una forma genérica.");
    }
    
    
    
}
