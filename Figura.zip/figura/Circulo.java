
//Crea una clase Circulo con un atributo radio y dos constructores, uno vacío y otro
//con un argumento (radio). Crea su getter/setter asociado y dos métodos públicos
//calcularArea y calcularPerimetro que devuelvan el tipo de datos adecuado.
//Ten en cuenta que si se crea un objeto de esta clase sin radio o su valor no es válido
//se tomará por defecto el valor de radio igual a 1.
//Haz pruebas desde

package main.java.model.figura;

public class Circulo extends Figura implements Comparable<Circulo> {
    private double radio;
    
    public Circulo() {
        this.radio = 1;
    }
    
    public Circulo(double radio) {
        this.radio = radio;
    }
    
    public double calcularArea() {
        return Math.PI * Math.pow(this.radio, 2);
    }
    
    public double calcularPerimetro() {
        return 2 * Math.PI * this.radio;
    }
    
    public double getRadio() {
        return this.radio;
    }
    
    public void setRadio(double radio) {
        this.radio = radio;
    }
    
    @Override
    public void mostrarInformacion() {
        System.out.println("Este es un círculo con radio " + radio + ".");
    }
    
    @Override
    public int compareTo(Circulo otroCirculo) {
        if (otroCirculo == null) {
            return 1; 
        }
        double areaActual = this.calcularArea();
        double areaOtro = otroCirculo.calcularArea();
        return Double.compare(areaActual, areaOtro);
    }
}

