package main.java.model.Avion;

import java.util.Scanner;

import main.java.model.Avion.Avion;



public class AeropuertoAvion {

	private static final String MENSAJE_AVION_CREACION = "¿Qué desea hacer? \n"
															+ "		1. Crear avión sólo con el identificador \n"
															+ "		2. Crear avión con identificador y compañía";
	private static Scanner sc; 
	
	
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		System.out.println(MENSAJE_AVION_CREACION);
		String opcion = sc.nextLine();
		
		while(!"1".equals(opcion) && !"2".equals(opcion)) {
			System.out.println(MENSAJE_AVION_CREACION);
			opcion = sc.nextLine();
		}
		
		int capacidad;
		do {
			System.out.println("Introduzca la capacidad del avión: \n");
			capacidad=Integer.valueOf(sc.nextLine());
		}while(capacidad<=0);
		
		System.out.println("Introduzca el id del avión: ");
		String idAvion = sc.nextLine();
		
		Avion avion;
		if("2".equals(opcion)){
			System.out.println("Introduzca la compañía: ");
			String compannia = sc.nextLine();
			
			avion= new Avion(idAvion, compannia, capacidad);
		}else {
			avion= new Avion(idAvion, capacidad);
		}
		
		
		gestionVuelos(avion, sc);
		
		sc.close();
	}
	
	
	private static void gestionVuelos(Avion avion, Scanner sc) {
		String opcion;
		
		do {
			
			System.out.println("Introduzca una opción (a-f, g:salir)");
			opcion= sc.nextLine();
			
			switch (opcion.toLowerCase()) {
				case "a": {
					
					System.out.println("¿Cuántos pasajeros van a viajar?");
					int viajeros = Integer.valueOf(sc.nextLine());
					System.out.println("¿Cuántos kilómetros volarán?");
					double kms = Double.valueOf(sc.nextLine());
					
					if(avion.asignarVuelo(viajeros, kms)) {
						System.out.println("Vuelo asignado correctamente.");
					}else {
						System.out.println("El avión no tiene capacidad suficiente.");
					}
					break;
				}			
				case "b": {
					System.out.println(String.format("Este avión ha realizado %s vuelos.", avion.getNumVuelos()));
					break;
				}			
				case "c": {
					System.out.println(String.format("Este avión ha volado %s kilómetros.", avion.getKmsVolados()));
					break;
				}
				case "d": {
					System.out.println(String.format("Este avión ha volado una media de %s kilómetros.", avion.getMediaKm()));
					break;
				}			
				case "e": {
					System.out.println("¿Qué compañia ha comprado el avión?");
					String newCompany=sc.nextLine();
					avion.setCompannia(newCompany);
					System.out.println("Cambio de compañía realizado correctamente.");
					break;
				}
				case "f": {
					System.out.println(avion);
					break;
				}
			}

		}while(!"g".equalsIgnoreCase(opcion));
	}

}