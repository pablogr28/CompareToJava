package main.java.model.Avion;

public class Avion {

	private String idAvion;
	private int capacidad;
	private int numVuelos;
	private double kmsVolados;
	private String compannia;
	
	public Avion(String idAvion, int capacidad)	{
		super();
		this.numVuelos=0;
		this.kmsVolados=0;
		this.idAvion=idAvion;
		this.capacidad=capacidad;
	}
	
	public Avion(String idAvion, String compannia, int capacidad) {
		this(idAvion, capacidad);
		this.compannia=compannia;
	}
	
	public boolean asignarVuelo(int capacidad, double kilometros) {
		boolean esPosibleAsignarVuelo = false;
		if (capacidad > 0 && capacidad <=this.capacidad){
			this.kmsVolados+=kilometros;
			this.numVuelos++;
			esPosibleAsignarVuelo = true;
		}
		return esPosibleAsignarVuelo;
	}
	// No es un getter al uso puesto que su nombre no coincide con el 
	// del atributo, como ocurre en el anterior
	public double getTotalKm() {
		return this.kmsVolados;
	}
	
	public String getIdAvion() {
		return idAvion;
	}


	public double getKmsVolados() {
		return kmsVolados;
	}

	public String getCompannia() {
		return compannia;
	}

	public void setCompannia(String compannia) {
		this.compannia = compannia;
	}

	public int getCapacidad() {
		return capacidad;
	}

	
	public int getNumVuelos() {
		return numVuelos;
	}
	

	public double getMediaKm() {
		return this.numVuelos>0? this.kmsVolados/this.numVuelos : 0;
	}
	
	//Comprobamos si un avión es igual a otro por su número de id
	// antes examinamos si el objeto que nos llega es null para evitar la excepción
	public boolean equals(Avion avion) {
		return avion!=null && this.idAvion.equals(avion.getIdAvion());
	}
	
	public String toString() {
		return String.format("Avión con id: %s de la compañía %s ha realizado\n"
				+ "%s vuelos, con un total de %s km y una media de %s "
				+ " km por vuelo", getIdAvion(), getCompannia(), getNumVuelos(), getKmsVolados(), getMediaKm());
	}
	

    public int compareTo(Avion otroAvion) {
        if (otroAvion == null) {
            return 1;
        }
        return Double.compare(this.kmsVolados, otroAvion.kmsVolados);
    }
}
